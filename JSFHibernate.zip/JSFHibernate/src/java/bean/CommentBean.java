/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;
import Dao.CommentDao;
import java.io.IOException;
import modelos.User;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.servlet.http.HttpServletRequest;
import modelos.Comment;
import org.primefaces.event.ToggleEvent;


/**
 *
 * @author henryhgomez
 */
public class CommentBean {

    /**
     * @return the commentId
     */
    public int getCommentId() {
        return commentId;
    }

    /**
     * @param commentId the commentId to set
     */
    public void setCommentId(int commentId) {
        this.commentId = commentId;
    }

    /**
     * @return the user
     */
    public String getUser() {
        if(FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user") == null){
           user = "";
            }else{
                user = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user").toString();
            }
     
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the subject
     */
    public String getSubject() {
        return subject;
    }

    /**
     * @param subject the subject to set
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * @return the body
     */
    public String getBody() {
        return body;
    }

    /**
     * @param body the body to set
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * @return the photoId
     */
    public int getPhotoId() {
        return photoId;
    }

    /**
     * @param photoId the photoId to set
     */
    public void setPhotoId(int photoId) {
        this.photoId = photoId;
    }

    /**
     * Creates a new instance of CommentBean
     */
    public CommentBean() {
    }
    
    private int commentId;
     private String user;
     private String subject;
     private   String body;
     private int photoId;
    
    public void addCommenta() throws Exception
    {
        
        
        
         FacesContext context = FacesContext.getCurrentInstance();

     if (context.getCurrentPhaseId() == PhaseId.RENDER_RESPONSE) {
        
    }
    else {
        // So, browser is requesting the image. Get ID value from actual request param.
        String id = context.getExternalContext().getRequestParameterMap().get("a");
        setPhotoId(Integer.parseInt(id));
       Comment comentario = new Comment(getCommentId(), getUser(), getSubject(), getBody(), Integer.parseInt(id));
                
        CommentDao CommentDao = new CommentDao();
        CommentDao.insertar(comentario); 
      
     }
        
       setUser("");
       setSubject("");
       setBody(""); 
       
    reload();    
    }
    public void addComment() throws Exception
    {
        
        
        
         FacesContext context = FacesContext.getCurrentInstance();

     if (context.getCurrentPhaseId() == PhaseId.RENDER_RESPONSE) {
        
    }
    else {
        // So, browser is requesting the image. Get ID value from actual request param.
        String id = context.getExternalContext().getRequestParameterMap().get("b");
        setPhotoId(Integer.parseInt(id));
       Comment comentario = new Comment(getCommentId(), getUser(), getSubject(), getBody(), Integer.parseInt(id));
                
        CommentDao CommentDao = new CommentDao();
        CommentDao.insertar(comentario); 
      
     }
        
       setUser("");
       setSubject("");
       setBody(""); 
       
    reload();    
    }
    
    
    public void agregarComment(Integer id) throws Exception
    {

        setPhotoId(id);
       Comment comentario = new Comment(getCommentId(), getUser(), getSubject(), getBody(), id);
                
        CommentDao CommentDao = new CommentDao();
        CommentDao.insertar(comentario); 
      
   
        
       setUser("");
       setSubject("");
       setBody(""); 
       ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
        ec.redirect("galeria.xhtml");
      
    }
    
    public void reload() throws IOException{
        ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
        ec.redirect(((HttpServletRequest) ec.getRequest()).getRequestURI());
        }
    
     public List<Comment> getcomentarios(Integer id) throws Exception  {
         CommentDao commentDao = new CommentDao();
       List <Comment> comentarios = commentDao.getComments(id);
        /*try{   
           
        
        
         } catch (Exception e) {
            e.printStackTrace();
             }*/
        
        return comentarios;
    }
    
    public void handleToggle(ToggleEvent event) {
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Toggled", "Visibility:" + event.getVisibility());
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }
}
