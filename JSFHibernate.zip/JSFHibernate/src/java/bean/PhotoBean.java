/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;
import Dao.PhotoDao;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import modelos.Photo;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.context.ExternalContext;
import javax.faces.event.PhaseId;
import javax.servlet.http.HttpServletRequest;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
/**
 *
 * @author HHenriquez
 */
public class PhotoBean {

    
    public boolean visible;
    /**
     * @return the visible
     */
    public boolean isVisible() {
        return visible;
    }

    /**
     * @param visible the visible to set
     */
    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    /**
     * @return the owner2
     */
    public String getOwner2() {
        return owner2;
    }

    /**
     * @param owner2 the owner2 to set
     */
    public void setOwner2(String owner2) {
        this.owner2 = owner2;
    }

    /**
     * @return the displayid
     */
    public int getDisplayid() {
        return displayid;
    }

    /**
     * @param displayid the displayid to set
     */
    public void setDisplayid(int displayid) {
        this.displayid = displayid;
    }

    /**
     * @return the displaytitle
     */
    public String getDisplaytitle() {
        return displaytitle;
    }

    /**
     * @param displaytitle the displaytitle to set
     */
    public void setDisplaytitle(String displaytitle) {
        this.displaytitle = displaytitle;
    }

   
    public UploadedFile file;
    public String namefile;
     public UploadedFile getFile() {
        return file;
    }
 
    public void setFile(UploadedFile file) {
        this.file = file;
    }
private String destination=".";

public void upload() {

    
    if(file != null) {  
        System.out.println("El archivo es" +file);
        FacesMessage msg = new FacesMessage("Archivo " + file.getFileName() + " cargada a servidor!");  
        FacesContext.getCurrentInstance().addMessage(null, msg);  
namefile =  file.getFileName();
        try {
           copyFile(file.getFileName(), file.getInputstream(),file.getSize());
       }
       catch (IOException e) {
          e.printStackTrace();
       }
    }
    
}  

public void copyFile(String fileName, InputStream in,long size) {
    try {
        OutputStream out = new FileOutputStream(new File(destination + fileName));

        int read = 0;
        byte[] bytes = new byte[(int)size];

        while ((read = in.read(bytes)) != -1) {
             out.write(bytes, 0, read);
        }

        in.close();
        out.flush();
        out.close();

        
    } catch (IOException e) {
       System.out.println(e.getMessage());
    }
}
    
     public void addPhoto() throws Exception
    {
   
        upload();
        
   
     File file = new File("." +  namefile);
        byte[] bFile = new byte[(int)file.length()]; 
        //new byte[(Long) file.length()];
 
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            fileInputStream.read(bFile);
            fileInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        this.setPhotoFile(bFile);        
        Photo photo = new Photo(getPhotoId(),getTitle(),getPhotoFile(),getDescription(),getCreateDate(),getOwner());                       
        PhotoDao photoDao = new PhotoDao();
        photoDao.insertar(photo);
      
        setTitle("");
        setDescription("");

    }





 
     public List<ImageObject> images;
    //public DefaultStreamedContent image;
    public List<ImageObject> cargar() throws Exception  {
         PhotoDao photoDao = new PhotoDao();
       List <Photo> photox = photoDao.getPhotos();
       DefaultStreamedContent imagex = null;
   
       List<ImageObject> images = new ArrayList<ImageObject>();
        try{   
           
        for (Photo foto : photox) {
            
            imagex = new DefaultStreamedContent(new ByteArrayInputStream(foto.getPhotoFile()), "image/png");
            ImageObject io = new ImageObject();
			
			io.setId(foto.getPhotoId());
                        io.setName(foto.getTitle());
                        io.setDescripcion(foto.getDescription());
                        io.setUser(foto.getOwner());
                        io.setFecha(foto.getCreateDate());
                        io.setContent(imagex);
            
            
            images.add(io);
                    
                   
        }
        
         } catch (Exception e) {
            e.printStackTrace();
             }
        
        return images;
    }
 
    
    public List<ImageObject> cargardatos(String id) throws Exception  {
         PhotoDao photoDao = new PhotoDao();
         
  
      
        int iden = Integer.parseInt(id);
         Photo foto = photoDao.getPhotoByID(iden);
        
       List<ImageObject> images = new ArrayList<ImageObject>();
         ImageObject io = new ImageObject();
			
			io.setId(foto.getPhotoId());
                        io.setName(foto.getTitle());
                        io.setDescripcion(foto.getDescription());
                        io.setUser(foto.getOwner());
                        io.setFecha(foto.getCreateDate());
                        
       
       images.add(io);
                      
       return images;
	
    
    }
    
    public List<ImageObject> getImages() {
        return images;
    }
    
    public String data = "1";
public StreamedContent getStreamedImageById() {
    
        DefaultStreamedContent image = null;
        PhotoDao photoDao = new PhotoDao();
     FacesContext context = FacesContext.getCurrentInstance();

     if (context.getCurrentPhaseId() == PhaseId.RENDER_RESPONSE) {
     
        return new DefaultStreamedContent();
    }
    else {
      
        String id = context.getExternalContext().getRequestParameterMap().get("b");
     
         byte[] imagen = photoDao.imagen(Integer.parseInt(id));

        return new DefaultStreamedContent(new ByteArrayInputStream(imagen),
					"image/png");
     }
    
}

public List<String> getStreamedImage() {
        
        List<String> imagenes = new ArrayList<String>();    
     
          PhotoDao photoDao = new PhotoDao();
       List <Photo> photox = photoDao.getPhotos();
        
        for (Photo foto : photox) {

            String v= String.valueOf(foto.getPhotoId());
            imagenes.add(""+v+"");
        }                            
        return imagenes;    
}


  public void deletePhoto (Integer id) throws Exception
    {
     
        FacesContext context = FacesContext.getCurrentInstance();
         if (context.getCurrentPhaseId() == PhaseId.RENDER_RESPONSE) {
     
        
    }
    else {
      setPhotoId(id);
        PhotoDao photoDao = new PhotoDao();
        photoDao.deletePhoto(id);
     
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("EXITO","Foto eliminada!"));
      
        
     } 
           
       // ec.redirect("galeria.xhtml");
    }

   public boolean verificarSesionusuario(Integer idphoto) throws Exception{
        boolean estado = false; 
        
        
        FacesContext context = FacesContext.getCurrentInstance();
         if (context.getCurrentPhaseId() == PhaseId.RENDER_RESPONSE) {
             if(idphoto == null) { 
            return false;
        }
     int demo = idphoto;
        
    }
    else {
      if(idphoto == null) { 
            return false;
        }
        PhotoDao x = new PhotoDao();
        Photo foto = x.getPhotoByID(idphoto);
        String nombre = foto.getOwner().trim();
        String usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user").toString().trim();
       try{
        if(usuario.equals(nombre))
        {   
            estado = true;
        
        }else{
            estado = false;
        
        } 
        }catch(Exception e){
        throw e;
        } 
        
     } 
         return estado;
   }


     
   
public StreamedContent getStreamedImageByIdx() {
    
        DefaultStreamedContent image = null;
        PhotoDao photoDao = new PhotoDao();
     FacesContext context = FacesContext.getCurrentInstance();

     if (context.getCurrentPhaseId() == PhaseId.RENDER_RESPONSE) {
       
        String id = context.getExternalContext().getRequestParameterMap().get("x");
        
        return new DefaultStreamedContent();
    }
    else {
        
        String id = context.getExternalContext().getRequestParameterMap().get("x");
       
         byte[] imagen = photoDao.imagen(Integer.parseInt(id));
      
        return new DefaultStreamedContent(new ByteArrayInputStream(imagen),
					"image/png");
     }
    
}

public StreamedContent getStreamedImageByIdc() {
    
        DefaultStreamedContent image = null;
        PhotoDao photoDao = new PhotoDao();
     FacesContext context = FacesContext.getCurrentInstance();

     if (context.getCurrentPhaseId() == PhaseId.RENDER_RESPONSE) {
       
        String id = context.getExternalContext().getRequestParameterMap().get("c");
        
        return new DefaultStreamedContent();
    }
    else {
        
        String id = context.getExternalContext().getRequestParameterMap().get("c");
       
         byte[] imagen = photoDao.imagen(Integer.parseInt(id));
      
        return new DefaultStreamedContent(new ByteArrayInputStream(imagen),
					"image/png");
     }
    
}

public void eliminarfoto(Integer id) throws Exception {
    try{
        setPhotoId(id);
        PhotoDao photoDao = new PhotoDao();
        photoDao.deletePhoto(id);
     FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("EXITO","Foto eliminada!"));
    }catch (Exception e) {
            e.printStackTrace();
    }finally{
    reload();
    }
        
    }
     
    public void reload() throws IOException{
        ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
        ec.redirect(((HttpServletRequest) ec.getRequest()).getRequestURI());
        }

public void displaydata(Integer id,String texto) {

    setDisplayid(id);
    setDisplaytitle(texto);
}




        public boolean comparar(String usuario) throws Exception{
        boolean valor = false;
        try{
        if(usuario != null && 
                this.usuariose().equals(usuario.trim()) )
        {
        visible = true;    
        return true;
        }
        }catch (Exception e){
        e.printStackTrace();
        }
        return valor;
        }
        
        public String usuariose() throws Exception{
        String nombre = "";
        try{
        
        
        if (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user").toString() == null)
        {
            nombre = "";
        }else{
        nombre = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user").toString();
        }
        }catch (Exception e){
    
            e.printStackTrace();
        
        }
        return nombre.toString().trim();
        }

        
           

    public String getParameterName1() {
        return parameterName1;
    }

    public void setParameterName1(String parameterName1) {
        if (parameterName1 == null){
        parameterName1 = "0";
        }else{
        setOwner2(parameterName1);
        }
        this.parameterName1 = parameterName1;
    }
        


  /**
     * @return the photoId
     */
    public int getPhotoId() {
        return photoId;
    }

    /**
     * @param photoId the photoId to set
     */
    public void setPhotoId(int photoId) {
        this.photoId = photoId;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the photoFile
     */
    public byte[] getPhotoFile() {
        return photoFile;
    }

    /**
     * @param photoFile the photoFile to set
     */
    public void setPhotoFile(byte[] photoFile) {
        this.photoFile = photoFile;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the createDate
     */
    public Date getCreateDate() {
        java.util.Date d = new java.util.Date();  
        java.sql.Date date2 = new java.sql.Date(d.getTime());
        
        createDate = date2;
        return createDate;
    }

    /**
     * @param createDate the createDate to set
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the owner
     */
    public String getOwner() {
         if(FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user") == null){
           owner = "";
            }else{
                owner = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user").toString();
            }
        return owner;
    }
    
    

    /**
     * @param owner the owner to set
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }

    /**
     * Creates a new instance of PhotoBean
     */
    public PhotoBean() {
        photoId = 0;
    }
    private int photoId ;
     private String title;
     private byte[] photoFile;
     private String description;
     private Date createDate;
     private String owner;
     private String owner2;
     private int displayid;
     private String displaytitle;
     private String parameterName1;
   
}
