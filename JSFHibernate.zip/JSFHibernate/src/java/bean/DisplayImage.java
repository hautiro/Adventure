/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

/**
 *
 * @author HHenriquez
 */

 

import java.sql.*;
import java.io.*;
import java.util.List;
import javax.servlet.*;
import javax.servlet.http.*;
import modelos.Photo;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;
 
public class DisplayImage extends HttpServlet {
    private static final long serialVersionUID = 4593558495041379082L;
    
    
    
    
    @Override
    public void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        
        InputStream sImage;
        
             Photo photo = null;
        Transaction tx = null;
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        
        try {
 
            String id = request.getParameter("Image_id");
            System.out.println("inside servlet–>" + id);
 
            
       
      
            tx = session.beginTransaction();
            String quertyString = "FROM Photo WHERE Photoid = :idToFind";
            Query query = session.createQuery(quertyString);
            query.setInteger("idToFind", Integer.parseInt(id));
            photo = (Photo) query.uniqueResult();
            
            
            
            if (photo != null) {
                
                response.getOutputStream().write(photo.getPhotoFile());
           
                
            }
 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
 

    
    
}
