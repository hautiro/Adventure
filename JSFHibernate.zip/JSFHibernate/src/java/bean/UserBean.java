/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;
import Dao.PhotoDao;
import Dao.UserDao;
import java.io.IOException;
import modelos.User;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.servlet.http.HttpServletRequest;
import modelos.Photo;
import org.primefaces.context.RequestContext;

/**
 *
 * @author henryhgomez
 */
public class UserBean {

    
    public void addUser()
    {
        User usuario = new User(getUser(),getName(),getPassword());
                
        UserDao userDao = new UserDao();
        userDao.insertar(usuario);
        setUser("");
        setName("");
        setPassword("");      
        
    }
    
    public void returnUserByuser()
    {
        UserDao userDao = new UserDao();
        User usuario = userDao.getUserByUser(getUser());
                
        if (usuario != null)
        {
           //getName(),getPassword()
            setUser(usuario.getUser());                   
            setName(usuario.getName());        
            setPassword(usuario.getPassword());
             FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("ERROR","encontrado " + getUser()));
        }
        else
        {
            setUser("");
        setName("");
        setPassword("");
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("ERROR","Usuario no encontrado!" + getUser()));
        }
    }
    
     public void deleteUser()
    {
         UserDao userDao = new UserDao();
        userDao.deleteUser(getUser());
        setUser("");
        setName("");
        setPassword("");
        
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("EXITO","Usuario "+ getUser() +" eliminado!"));
    }
     
        public void updateUser()
    {
        User newusuario = new User(getUser(),getName(),getPassword());
        UserDao usuarioDao = new UserDao();
        
        usuarioDao.updateProfesor(getUser(), newusuario);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("EXITO","Usuario Actualizado correctamente"));
    }
    
    
        public void verificarDatos() throws Exception{
        UserDao usuDAO = new UserDao();
        User us;

       // String resultado;
        try{
        us = usuDAO.verificarDatos(getUser(),getPassword());
        if (us != null){
         FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("user",us.getUser());
       // resultado = "exito";
        reload();
            
        }else{
        reload();  
        }
           
        }catch(Exception e){
        throw e;
        }        
        //return resultado;
        }
        
        public boolean verificarSesion(){
        boolean estado;
        if(FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user") == null){
        estado = false;
        }else{
            estado = true;
        }
        return estado;
        }
       //http://balusc.omnifaces.org/2006/06/communication-in-jsf.html#PassingGETParametersFromJSFToBackingBeans
         public boolean verificarSesionusuario(Integer idphoto) throws Exception{
        boolean estado = false; 
        
        
        FacesContext context = FacesContext.getCurrentInstance();
         if (context.getCurrentPhaseId() == PhaseId.RENDER_RESPONSE) {
             if(idphoto == null) { 
            return false;
        }
     int demo = idphoto;
        
    }
    else {
      if(idphoto == null) { 
            return false;
        }
        PhotoDao x = new PhotoDao();
        Photo foto = x.getPhotoByID(idphoto);
        String nombre = foto.getOwner().trim();
        String usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user").toString().trim();
       try{
        if(usuario.equals(nombre))
        {   
            estado = true;
        
        }else{
            estado = false;
        
        } 
        }catch(Exception e){
        throw e;
        } 
        
     } 
        
       
        return estado;
        }
        
       public boolean verificarSesionusuario2() throws Exception{
        boolean estado;
        estado = false;
        
        try{
        if(FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user") != null)
        {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        Map params = facesContext.getExternalContext().getRequestParameterMap();
        Integer parametroObtenido= new Integer((String) params.get("defaultHeader2"));

        PhotoDao x = new PhotoDao();
        Photo foto = x.getPhotoByID(parametroObtenido);
        
         String nombre = foto.getOwner().trim();
        String usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user").toString().trim();
        if(usuario.equals(nombre))  
        {
            estado = true;
        
        }else{
            estado = false;
        
        }
        }       
                
                
        }catch(Exception e){
        throw e;
        } 
        
        return estado;
        }
       
        public String cerrarsesion() throws Exception{
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        //reload();
        return "";
        }
        
        public void reload() throws IOException{
        ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
        ec.redirect(((HttpServletRequest) ec.getRequest()).getRequestURI());
        }
        
    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Creates a new instance of UserBean
     */
    public UserBean() {
    }
    
    private String user;
    private String name;
    private String password;
}
