/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
//import java.io.InputStream;
import java.io.IOException;
import java.sql.SQLException;
import modelos.Photo;
import util.HibernateUtil;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
/**
 *
 * @author HHenriquez
 */
public class PhotoDao {
    
    public void insertar(Photo photo) throws Exception{
    Transaction tx = null;
         Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
            session.save(photo);
            session.getTransaction().commit();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("EXITO","Foto Ingresado al sistema " ));
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Error",e.getMessage() ));
            
            if(tx != null)
            {
                tx.rollback();
            }
        }
    }
    
    public Photo getPhotoByID(int idPhoto)
    {
        Photo photo = null;
        Transaction tx = null;
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
            String quertyString = "FROM Photo WHERE Photoid = :idToFind ";
            Query query = session.createQuery(quertyString);
            query.setInteger("idToFind", idPhoto);
            photo = (Photo) query.uniqueResult();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();            
        }
        finally
        {
            session.flush();
            session.close();
        }
        
        return photo;
    }
    
    public List<Photo> getPhotos()
    {
        List <Photo> photo = null;
        Transaction tx = null;
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
            String quertyString = "FROM Photo ORDER BY Createdate DESC";
            Query query = session.createQuery(quertyString);
             photo = query.list();
        }
        catch(Exception e)
        {
            e.printStackTrace();            
        }
        finally
        {
            session.flush();
            session.close();
        }
        
        return photo;
    }
    
    public byte[] imagen(Integer id)
    {

        
             Photo photo = null;
        Transaction tx = null;
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        
        try {
           
       
      
            tx = session.beginTransaction();
            String quertyString = "FROM Photo WHERE Photoid = :idToFind";
            Query query = session.createQuery(quertyString);
            query.setInteger("idToFind", id);
            photo = (Photo) query.uniqueResult();
            
            
            
            if (photo != null) {
                
                return photo.getPhotoFile();                           
            }
 
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    
    
    	//private static final long serialVersionUID = 1L;
 
	public byte[] getProductImage(String productId) throws IOException,
			SQLException {
		byte[] productImage = null;
		Photo photo = null;
        Transaction tx = null;
        
            Session session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            String quertyString = "FROM Photo WHERE Photoid = :idToFind";
            Query query = session.createQuery(quertyString);
            query.setInteger("idToFind", Integer.parseInt(productId));
            photo = (Photo) query.uniqueResult();
            
            
          
            if (photo != null) {
                
                productImage = photo.getPhotoFile();                           
            }
            
		
	return productImage;
        }
        
        
         public void deletePhoto(Integer photo)
   
    {
        Transaction tx = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
            Photo usuario = (Photo) session.load( Photo.class, new Integer(photo));
            session.delete(usuario);
            session.getTransaction().commit();
        }
        catch(RuntimeException e)
        {
            if(tx != null)
            {
                tx.rollback();
            }    
            e.printStackTrace();
        }
        finally
        {
            session.flush();
            session.close();
        }
    }
        
}
