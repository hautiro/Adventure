/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
import modelos.User;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;
/**
 *
 * @author henryhgomez
 */
public class UserDao {

    /**
     * Creates a new instance of UserDao
     */
    public UserDao() {
    }

 public void insertar(User usuario){
    Transaction tx = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
            session.save(usuario);
            session.getTransaction().commit();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("EXITO","Usuario Ingresado al sistema " ));
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            if(tx != null)
            {
                tx.rollback();
            }
        }
    }
    
      public void deleteUser(String user)
    {
        Transaction tx = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
            User usuario = (User) session.load( User.class, new String(user));
            session.delete(usuario);
            session.getTransaction().commit();
        }
        catch(RuntimeException e)
        {
            if(tx != null)
            {
                tx.rollback();
            }    
            e.printStackTrace();
        }
        finally
        {
            session.flush();
            session.close();
        }
    }
      
    public List<User> getUsuario()
    {
       // User usuario = null;
        Transaction tx = null;
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
            String quertyString = "FROM User";
            Query query = session.createQuery(quertyString);
           // query.setInteger("idToFind", idProfesor);
           List<User>  lista=query.list();
           return lista;
        }
        catch(Exception e)
        {
            e.printStackTrace();            
        }
        finally
        {
            session.flush();
            session.close();
        }
        return null;
    }

    
    public User getUserByUser(String user)
    {
        User usuario = null;
        Transaction tx = null;
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
            String quertyString = "FROM User WHERE user = '"+ user +"'";
            Query query = session.createQuery(quertyString);
            //query.setString("usuario", user);
            usuario = (User) query.uniqueResult();
            // FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("ERROR","xyz!" + user));
        }
        catch(Exception e)
        {
            e.printStackTrace(); 
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("ERROR",e.getMessage()));
        }
        finally
        {
            session.flush();
            session.close();
        }
        
        return usuario;
    }
    
    public void updateProfesor(String user,User newUser)
    {
        Transaction tx = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {                        
            tx = session.beginTransaction();
            User oldUser = (User) session.load(User.class,new String(user));

            oldUser.setName(newUser.getName());
            oldUser.setPassword(newUser.getPassword());
            oldUser.setUser(newUser.getUser());

            session.update(oldUser);
            tx.commit();
        }
        catch(RuntimeException e)
        {
            if(tx != null)
            {
                tx.rollback();
            }    
            e.printStackTrace();
        }
        finally
        {
            session.flush();
            session.close();
        }
    }
    
    private Session session;
    
    public User verificarDatos(String usuario,String password) throws Exception
    {
        User us =null;
        try 
        {
            Session session1 = HibernateUtil.getSessionFactory().openSession();

            String hql = "FROM User WHERE user='" + usuario + "' and password='" + password + "'";

            Query query = session1.createQuery(hql);

            if(!query.list().isEmpty())
            {
                us= (User) query.list().get(0);
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("ERROR",e.getMessage()));
        } 
        catch (Throwable t) 
        {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("ERROR",t.getMessage()));
            throw new Exception(t);
        }
        return us;    
    }
}


    
   

