/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
import modelos.Comment;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;
/**
 *
 * @author henryhgomez
 */
public class CommentDao {
     public void insertar(Comment comentario){
    Transaction tx = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            int prueba = comentario.getPhotoId();
            tx = session.beginTransaction();
            session.save(comentario);
            session.getTransaction().commit();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("EXITO","Comentario Ingresado al sistema " ));
            
        }
        catch(Exception e)
        {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Error","Error al ingresar al sistema " +e.getMessage()  ));
            
            e.printStackTrace();
            if(tx != null)
            {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Error","Error al ingresar al sistema " +e.getMessage()  ));

                tx.rollback();
            }
        }
    }
     
      public List<Comment> getComments(Integer id)
    {
        List <Comment> comentarios = null;
        Transaction tx = null;
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        try
        {
            tx = session.beginTransaction();
             String quertyString = "FROM Comment WHERE Photoid = :idToFind";
            Query query = session.createQuery(quertyString);
            query.setInteger("idToFind", id);
             comentarios = query.list();
        }
        catch(Exception e)
        {
            e.printStackTrace();            
        }
        finally
        {
            session.flush();
            session.close();
        }
        
        return comentarios;
    }
     
}
